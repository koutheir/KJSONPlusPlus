
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <ctype.h>

#include "json.h"

static void json_destroy_simple_value(json_value_t * value);
static void json_destroy_string_value(json_value_t * value);
static void json_destroy_pair(json_value_pair_t * pair);
static void json_destroy_object_value(json_value_t * value);
static void json_destroy_array_value(json_value_t * value);

static int json_compare_null_values(const json_value_t * value1, const json_value_t * value2);
static int json_compare_boolean_values(const json_value_t * value1, const json_value_t * value2);
static int json_compare_int_values(const json_value_t * value1, const json_value_t * value2);
static int json_compare_double_values(const json_value_t * value1, const json_value_t * value2);
static int json_compare_string_values(const json_value_t * value1, const json_value_t * value2);
static int json_compare_object_values(const json_value_t * value1, const json_value_t * value2);
static int json_compare_array_values(const json_value_t * value1, const json_value_t * value2);

static void destroy_object_element_proc(linked_list_t *list, void *node_data);
static void destroy_array_element_proc(linked_list_t *list, void *node_data);
static int compare_value_proc(const linked_list_t *list, const void *node_data_1, const void *node_data_2);

typedef void (* json_destroy_value_proc)(json_value_t * value);
typedef int (* json_compare_values_proc)(const json_value_t * value1, const json_value_t * value2);

static json_destroy_value_proc json_destroy_dispatcher[] = {
	json_destroy_simple_value,	// null_data_type
	json_destroy_simple_value,	// boolean_data_type
	json_destroy_simple_value,	// int_data_type
	json_destroy_simple_value,	// double_data_type
	json_destroy_string_value,	// string_data_type
	json_destroy_object_value,	// object_data_type
	json_destroy_array_value,	// array_data_type
};

static json_compare_values_proc json_compare_dispatcher[] = {
	json_compare_null_values,		// null_data_type
	json_compare_boolean_values,	// boolean_data_type
	json_compare_int_values,		// int_data_type
	json_compare_double_values,		// double_data_type
	json_compare_string_values,		// string_data_type
	json_compare_object_values,		// object_data_type
	json_compare_array_values,		// array_data_type
};

char *json_unescape_string(const char *str, int len)
{
	//This copies the string then unescapes it
	int i, j, n;
	char *rs, num[6];

	if (len == -1) len = strlen(str);

	rs = (char *)malloc(len + 1);

	for (i=0, j=0; j < len; ++i, ++j) {
		if (str[j] != '\\') {rs[i] = str[j]; continue;}

		++j;
		switch (str[j]) {
		case 't':	rs[i] = '\t'; break;
		case 'n':	rs[i] = '\n'; break;
		case 'r':	rs[i] = '\r'; break;
		case 'b':	rs[i] = '\b'; break;
		case 'f':	rs[i] = '\f'; break;
		case '\'':	rs[i] = '\''; break;
		case '\"':	rs[i] = '\"'; break;
		case '\\':	rs[i] = '\\'; break;
		case '/':	rs[i] = '/'; break;
		
		case 'u':	// Escape Unicode character
			for (n=0; n < 4; ++n)
				if (!isxdigit(num[n] = str[++j]))
					goto done;
			num[n] = '\0';
			
			*(unsigned short *)(rs + i) = (unsigned short)strtoul(num, NULL, 16);
			break;

		case '0':	// Escape numeric sequence
			for (n=0; n < 3; ++n)
				if (!isdigit(num[n] = str[++j]))
					goto done;
			num[n] = '\0';
			
			rs[i] = (char)strtoul(num, NULL, 8);
		}
	}
	
	done:
	rs[i] = '\0';
	return rs;
}

void json_on_parse_error(const char * error_desc)
{
	fprintf(stderr, "%s.\n", error_desc);
}

json_value_t * json_create_null_value()
{
	json_value_t * value = malloc(sizeof(json_value_t));
	if (!value) return NULL;
	
	value->data_type = null_data_type;
	
	return value;
}

json_value_t * json_create_boolean_value(int data)
{
	json_value_t * value = malloc(sizeof(json_value_t));
	if (!value) return NULL;
	
	value->data_type = boolean_data_type;
	value->data.data_boolean = data;
	
	return value;
}

json_value_t * json_create_integer_value(int data)
{
	json_value_t * value = malloc(sizeof(json_value_t));
	if (!value) return NULL;
	
	value->data_type = int_data_type;
	value->data.data_int = data;
	
	return value;
}

json_value_t * json_create_double_value(double data)
{
	json_value_t * value = malloc(sizeof(json_value_t));
	if (!value) return NULL;
	
	value->data_type = double_data_type;
	value->data.data_double = data;
	
	return value;
}

json_value_t * json_create_string_value(char * data, int length, int take_ownership)
{
	json_value_t * value;
	if (!take_ownership) data = strdup(data);
	if (!data) return NULL;

	if (!(value = malloc(sizeof(json_value_t)))) {
		int r = errno;
		if (!take_ownership) free(data);
		errno = r;
		return NULL;
	}
	
	value->data_type = string_data_type;
	value->data.data_string.data = data;
	value->data.data_string.length = length;

	return value;
}

json_value_t * json_create_empty_object_value()
{
	json_value_t * value = malloc(sizeof(json_value_t));
	if (!value) return NULL;
	
	value->data_type = object_data_type;
	value->data.data_object = ll_create(value, destroy_object_element_proc, compare_value_proc);
	
	return value;
}

json_value_t * json_append_to_object_value(json_value_t * object, char * name, int name_length, json_value_t * value, int take_name_ownership, int destroy_object_if_fails)
{
	int r;
	json_value_pair_t * pair = NULL;
	if (!take_name_ownership) name = strdup(name);
	if (!name) {r = errno; goto error_occured;}

	if (!(pair = malloc(sizeof(json_value_pair_t)))) {r = errno; goto error_occured;}
	
	pair->name.data = name;
	pair->name.length = name_length;
	pair->value = value;
	
	if ((r = ll_append((linked_list_t *)(object->data.data_object), pair))) goto error_occured;
	return object;
	
	error_occured:
	if (!take_name_ownership) free(name);
	free(pair);
	if (destroy_object_if_fails) json_destroy_value(object);
	errno = r;
	return NULL;
}

json_value_t * json_create_empty_array_value()
{
	json_value_t * value = malloc(sizeof(json_value_t));
	if (!value) return NULL;
	
	value->data_type = array_data_type;
	value->data.data_array = ll_create(value, destroy_array_element_proc, compare_value_proc);
	
	return value;
}

json_value_t * json_append_to_array_value(json_value_t * array, json_value_t * value, int destroy_array_if_fails)
{
	int r = ll_append((linked_list_t *)(array->data.data_array), value);
	if (r) {
		if (destroy_array_if_fails) json_destroy_value(array);
		errno = r;
		array = NULL;
	}
	return array;
}

void json_destroy_value(json_value_t * value)
{
	if (!value) return;
	(json_destroy_dispatcher[value->data_type])(value);
}

int json_compare_values(const json_value_t * value1, const json_value_t * value2)
{
	if (value1->data_type != value2->data_type)
		return (value1->data_type - value2->data_type);
		
	return (json_compare_dispatcher[value1->data_type])(value1, value2);
}

linked_list_t * json_get_object_linked_list(json_value_t * value)
{
	return (linked_list_t *)value;
}

linked_list_t * json_get_array_linked_list(json_value_t * value)
{
	return (linked_list_t *)value;
}

void json_destroy_simple_value(json_value_t * value)
{
	free(value);
}

void json_destroy_string_value(json_value_t * value)
{
	free(value->data.data_string.data);
	free(value);
}

void json_destroy_pair(json_value_pair_t * pair)
{
	json_destroy_value(pair->value);
	free(pair->name.data);
	free(pair);
}

void json_destroy_object_value(json_value_t * value)
{
	ll_destroy(value->data.data_object, 1);
	free(value);
}

void json_destroy_array_value(json_value_t * value)
{
	ll_destroy(value->data.data_array, 1);
	free(value);
}

int json_compare_null_values(const json_value_t * value1, const json_value_t * value2)
{
	return 0;	//All nulls are equal
}

int json_compare_boolean_values(const json_value_t * value1, const json_value_t * value2)
{
	return (value1->data.data_boolean - value2->data.data_boolean);
}

int json_compare_int_values(const json_value_t * value1, const json_value_t * value2)
{
	return (value1->data.data_int - value2->data.data_int);
}

int json_compare_double_values(const json_value_t * value1, const json_value_t * value2)
{
	if (value1->data.data_double == value2->data.data_double) return 0;
	if (value1->data.data_double > value2->data.data_double) return 1;
	return -1;
}

int json_compare_string_values(const json_value_t * value1, const json_value_t * value2)
{
	return strcmp(value1->data.data_string.data, value2->data.data_string.data);
}

int json_compare_object_values(const json_value_t * value1, const json_value_t * value2)
{
	/*
		WARNING: This comparison is for the moment superficial. This is a
		container object so it should be compared deeply by comparing its
		sub-elements.
	*/
	return (value1->data.data_object - value2->data.data_object);
}

int json_compare_array_values(const json_value_t * value1, const json_value_t * value2)
{
	/*
		WARNING: This comparison is for the moment superficial. This is a
		container object so it should be compared deeply by comparing its
		sub-elements.
	*/
	return (value1->data.data_array - value2->data.data_array);
}

void destroy_object_element_proc(linked_list_t *list, void *node_data)
{
	json_destroy_pair((json_value_pair_t *)node_data);
}

void destroy_array_element_proc(linked_list_t *list, void *node_data)
{
	json_destroy_value((json_value_t *)node_data);
}

int compare_value_proc(const linked_list_t *list, const void *node_data_1, const void *node_data_2)
{
	return json_compare_values((json_value_t *)node_data_1, (json_value_t *)node_data_2);
}

// #include "json_parser.c"
