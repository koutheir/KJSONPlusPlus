
#ifndef _JSON_H_
#define _JSON_H_

#include "linked_list.h"

typedef enum {
	erronous_data_type = 0xFF,
	null_data_type = 0,
	boolean_data_type,
	int_data_type,
	double_data_type,
	string_data_type,
	object_data_type,
	array_data_type,
} json_data_type_t;

typedef struct {
	int		length;
	char *	data;
} json_value_string_t;

typedef linked_list_t *		json_value_object_t;

typedef linked_list_t *		json_value_array_t;

typedef union {
	int					data_int;
	double				data_double;
	unsigned char		data_boolean;
	json_value_string_t	data_string;
	json_value_object_t	data_object;
	json_value_array_t	data_array;
} json_value_data_t;

typedef struct {
	json_data_type_t	data_type;
	json_value_data_t	data;
} json_value_t;

typedef struct {
	json_value_string_t	name;
	json_value_t *		value;
} json_value_pair_t;

extern void json_on_parse_error(const char * error_desc);
extern char *json_unescape_string(const char * str, int len);

extern json_value_t * json_create_null_value();
extern json_value_t * json_create_boolean_value(int value);
extern json_value_t * json_create_integer_value(int value);
extern json_value_t * json_create_double_value(double value);
extern json_value_t * json_create_string_value(char * value, int length, int take_ownership);

extern json_value_t * json_create_empty_object_value();
extern json_value_t * json_append_to_object_value(json_value_t * object, char * name, int name_length, json_value_t * value, int take_name_ownership, int destroy_object_if_fails);

extern json_value_t * json_create_empty_array_value();
extern json_value_t * json_append_to_array_value(json_value_t * array, json_value_t * value, int destroy_array_if_fails);

extern void json_destroy_value(json_value_t * value);
extern int json_compare_values(const json_value_t * value1, const json_value_t * value2);

extern linked_list_t * json_get_object_linked_list(json_value_t * value);
extern linked_list_t * json_get_array_linked_list(json_value_t * value);

#endif
/*
#ifndef YY_EXTRA_TYPE
#define YY_EXTRA_TYPE void *
#endif

#ifndef YY_TYPEDEF_YY_SCANNER_T
#define YY_TYPEDEF_YY_SCANNER_T
typedef void* yyscan_t;
#endif


#include "json_parser.h"
*/

extern void yyrestart(FILE *input_file);
extern int yyparse(void **json_tree);
