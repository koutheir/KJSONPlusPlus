
#include "linked_list.h"

#include <malloc.h>
#include <errno.h>
#include <stdlib.h>


void ll_destroy_node_data_default_handler(linked_list_t *list, void *node_data)
{
	free(node_data);
}

int ll_compare_node_data_default_handler(const linked_list_t *list, const void *node_data_1, const void *node_data_2)
{
	return ((const char *)node_data_1 - (const char *)node_data_2);
}

void * ll_copy_node_data_default_handler(linked_list_t *src_list, linked_list_t *dest_list, void *node_data)
{
	return node_data;
}

linked_list_t *ll_create(void *user_data, ll_destroy_node_data_proc destroy_node_data, ll_compare_node_data_proc compare_node_data)
{
	linked_list_t *list = calloc(1, sizeof(linked_list_t));
	if (!list) return NULL;

	list->user_data = user_data;
	list->destroy_node_data = ((destroy_node_data == NULL) ? ll_destroy_node_data_default_handler : destroy_node_data);
	list->compare_node_data = ((compare_node_data == NULL) ? ll_compare_node_data_default_handler : compare_node_data);
	errno = 0;
	return list;
}

void ll_destroy(linked_list_t *list, int delete_data)
{
	ll_remove_all(list, delete_data);
	free(list);
}

linked_list_t *ll_copy(linked_list_t *list, ll_copy_node_data_proc copy_node_data)
{
	int r = 0;
	linked_list_t *result_list=NULL;
	ll_node *node=NULL;

	if (!list) {errno = EINVAL; return NULL;}
	if (!copy_node_data) copy_node_data = ll_copy_node_data_default_handler;

	if (!(result_list = ll_create(list->user_data, list->destroy_node_data, list->compare_node_data)))
		return NULL;

	while ((node = ll_get_next(list, node)) != NULL) {
		if ((r = ll_append(result_list, (copy_node_data)(list, result_list, ll_get_data(list, node))))) {
			ll_destroy(result_list, copy_node_data != ll_copy_node_data_default_handler);
			errno = r;
			return NULL;
		}
	}

	errno = 0;
	return result_list;
}

void *ll_get_user_data(const linked_list_t *list)
{
	return list->user_data;
}

void ll_set_user_data(linked_list_t *list, void *user_data)
{
	list->user_data = user_data;
}

int ll_empty(const linked_list_t *list)
{
	if (!list) {errno = EINVAL; return -1;}
	errno = 0;
	return (list->count == 0);
}

int ll_count(const linked_list_t *list)
{
	if (!list) {errno = EINVAL; return -1;}
	errno = 0;
	return list->count;
}

int ll_find_data(const linked_list_t *list, const ll_node *start_node, ll_compare_node_data_proc compare_node_data, const void *data, ll_node **found_node)
{
	ll_node *node = (ll_node *)start_node;

	if (!list) return (errno = EINVAL);
	if (!compare_node_data) compare_node_data = list->compare_node_data;

	while ((node = ll_get_next(list, node)) != NULL) {
		if ((compare_node_data)(list, data, ll_get_data(list, node)) == 0) {
			if (found_node != NULL) *found_node = node;
			return (errno = 0);
		}
	}
	return (errno = ENOENT);
}

int ll_prepend(linked_list_t *list, void *data)
{
	return ll_insert_before(list, NULL, data);
}

int ll_append(linked_list_t *list, void *data)
{
	return ll_insert_after(list, NULL, data);
}

int ll_insert_before(linked_list_t *list, ll_node *node, void *data)
{
	ll_node *p;
	if (!list) return (errno = EINVAL);
	if (!node) node = list->head;

	if (!(p = (ll_node *)malloc(sizeof(ll_node)))) return errno;

	p->data = data;
	p->next = node;

	if (node != NULL) {
		p->previous = node->previous;

		if (node->previous != NULL) node->previous->next = p;
		node->previous = p;
	} else
		p->previous = NULL;

	if (p->previous == NULL) list->head = p;
	if (p->next == NULL) list->tail = p;
	list->count++;
	return (errno = 0);
}

int ll_insert_after(linked_list_t *list, ll_node *node, void *data)
{
	ll_node *p;
	if (!list) return (errno = EINVAL);
	if (!node) node = list->tail;

	if (!(p = (ll_node *)malloc(sizeof(ll_node)))) return errno;

	p->data = data;
	p->previous = node;

	if (node != NULL) {
		p->next = node->next;

		if (node->next != NULL) node->next->previous = p;
		node->next = p;
	} else
		p->next = NULL;

	if (p->previous == NULL) list->head = p;
	if (p->next == NULL) list->tail = p;
	list->count++;
	return (errno = 0);
}

int ll_remove(linked_list_t *list, ll_node *node, int delete_data)
{
	if (!list || !node) return (errno = EINVAL);

	if (node->previous == NULL)
		list->head = node->next;
	else
		node->previous->next = node->next;

	if (node->next == NULL)
		list->tail = node->previous;
	else
		node->next->previous = node->previous;

	if (delete_data) (list->destroy_node_data)(list, node->data);
	free(node);
	list->count--;
	return (errno = 0);
}

int ll_remove_all(linked_list_t *list, int delete_data)
{
	ll_node *p, *next;
	if (!list) return (errno = EINVAL);

	if (!(p = list->head)) return (errno = 0);

	do {
		next = p->next;

		if (delete_data) (list->destroy_node_data)(list, p->data);
		free(p);

		p = next;
	} while (p != NULL);

	list->head = list->tail = NULL;
	list->count = 0;
	return (errno = 0);
}

ll_node *ll_get_next(const linked_list_t *list, const ll_node *node)
{
	if (!list) {errno = EINVAL; return NULL;}
	errno = 0;
	return (node == NULL ? list->head : node->next);
}

ll_node *ll_get_previous(const linked_list_t *list, const ll_node *node)
{
	if (!list) {errno = EINVAL; return NULL;}
	errno = 0;
	return (node == NULL ? list->tail : node->previous);
}

void *ll_get_data(const linked_list_t *list, const ll_node *node)
{
	if (!list || !node) {errno = EINVAL; return NULL;}
	errno = 0;
	return node->data;
}

int ll_set_data(linked_list_t *list, ll_node *node, void *data, int destroy_existing)
{
	if (!list || !node) return (errno = EINVAL);
	if ((node->data != NULL) && (destroy_existing))
		(list->destroy_node_data)(list, node->data);

	node->data = data;
	return (errno = 0);
}
