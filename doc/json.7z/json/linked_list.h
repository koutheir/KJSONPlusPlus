
#ifndef _LINKED_LIST_H_
#define _LINKED_LIST_H_


struct linked_list_t_;
struct ll_node_;

/**
	Destroys the data of a node.
	The default handler calls 'free' on the data.
*/
typedef void (* ll_destroy_node_data_proc)(struct linked_list_t_ *list, void *node_data);

/**
	Compares the data of two nodes.
	Returns zero if the data match. Otherwise returns a positive integer or a
	negative integer depending on some predefined order.
	The default handler compares the pointers, not the data pointed to.
*/
typedef int (* ll_compare_node_data_proc)(const struct linked_list_t_ *list, const void *node_data_1, const void *node_data_2);

/**
	Copies the data of a node.
	The default handler returns the same source data, thus copying the pointer
	to data.
*/
typedef void * (* ll_copy_node_data_proc)(struct linked_list_t_ *src_list, struct linked_list_t_ *dest_list, void *node_data);

typedef struct ll_node_ {
	struct ll_node_	*previous, *next;
	void			*data;
} ll_node;

typedef struct linked_list_t_ {
	int							count;
	ll_node						*head, *tail;
	ll_destroy_node_data_proc	destroy_node_data;
	ll_compare_node_data_proc	compare_node_data;
	void						*user_data;
} linked_list_t;


/**
	Creates and returns a new doubly-linked list.
	destroy_node_data specifies the node's data destruction routine to be called
	in order to free a node's data from memory. If this is NULL, then the
	default routine is used (ll_destroy_node_data_default_handler).
	On error, it returns NULL and sets errno appropriately.
*/
linked_list_t *ll_create(void *user_data, ll_destroy_node_data_proc destroy_node_data, ll_compare_node_data_proc compare_node_data);

/**
	Destroys list after deleting all its nodes from memory.
	If delete_data is 1 then the nodes' associated data is deleted from memory.
*/
void ll_destroy(linked_list_t *list, int delete_data);

/**
	Creates and returns a doubly-linked list that is a copy of the given list.
*/
linked_list_t *ll_copy(linked_list_t *list, ll_copy_node_data_proc copy_node_data);

/**
	Returns the user data associated with the list.
*/
void *ll_get_user_data(const linked_list_t *list);

/**
	Sets the user data associated with the list.
*/
void ll_set_user_data(linked_list_t *list, void *user_data);

/**
	Returns 1 if the list has no nodes.
	On error, it returns -1 and sets errno appropriately.
*/
int ll_empty(const linked_list_t *list);

/**
	Returns the number of nodes in the list.
	On error, it returns -1 and sets errno appropriately.
*/
int ll_count(const linked_list_t *list);

/**
	Search for a given data in the list starting from a given node.

	Data comparison function can be specified to allow different types of search
	on the data. If compare_node_data is NULL, then the list-associated
	comparison function is used in the search. If no comparison function was
	associated with the list when it was created, then the default comparison
	function will be used.

	If start_node is NULL, then the search starts from the beginning of the list.
	If found_node is NULL, then the search will not return any eventually found
	node. This can be useful to merely test for the existence of the data.

	If found_node is not NULL and data is found, the node holding it is returned.
	Returns errno.
*/
int ll_find_data(const linked_list_t *list, const ll_node *start_node, ll_compare_node_data_proc compare_node_data, const void *data, ll_node **found_node);

/**
	Inserts a new node in the list and makes it the first node of the list.
	Returns errno.
*/
int ll_prepend(linked_list_t *list, void *data);

/**
	Inserts a new node in the list and makes it the last node of the list.
	Returns errno.
*/
int ll_append(linked_list_t *list, void *data);

/**
	Inserts a new node in the list and places it before another existing node.
	If node is NULL then the inserted node will be the first item of the list.
	Returns errno.
*/
int ll_insert_before(linked_list_t *list, ll_node *node, void *data);

/**
	Inserts a new node in the list and places it after another existing node.
	If node is NULL then the inserted node will be the last item of the list.
	Returns errno.
*/
int ll_insert_after(linked_list_t *list, ll_node *node, void *data);

/**
	Removes a node from the list.
	If delete_data is 1 then the node's associated data is deleted from memory.
	Returns errno.
*/
int ll_remove(linked_list_t *list, ll_node *node, int delete_data);

/**
	Removes all existing nodes from the list.
	If delete_data is 1 then the nodes' associated data is deleted from memory.
	The list itself remains in memory and can be used further.
	Returns errno.
*/
int ll_remove_all(linked_list_t *list, int delete_data);

/**
	Returns the node following the given node in the list.
	If node is NULL then the first item of the list is returned.
	If no more nodes follow the given node then NULL is returned and errno
	is set to zero indicating no error.
	On error, it returns NULL and sets errno appropriately.
*/
ll_node *ll_get_next(const linked_list_t *list, const ll_node *node);

/**
	Returns the node preceding the given node in the list.
	If node is NULL then the last item of the list is returned.
	If no more nodes preceed the given node then NULL is returned and errno
	is set to zero indicating no error.
	On error, it returns NULL and sets errno appropriately.
*/
ll_node *ll_get_previous(const linked_list_t *list, const ll_node *node);

/**
	Returns the pointer to data associated with the given node.
	On error, it returns NULL and sets errno appropriately.
*/
void *ll_get_data(const linked_list_t *list, const ll_node *node);

/**
	Changes the data associated with the given node.
	If destroy_existing is 1 and some data was already associated with the node
	then that data is deleted from memory before associating the given data with
	the node.
	Returns errno.
*/
int ll_set_data(linked_list_t *list, ll_node *node, void *data, int destroy_existing);

/**
	Deletes a block of data allocated using malloc/calloc/realloc.
	This function is called whenever a node's data has to be freed.
*/
void ll_destroy_node_data_default_handler(linked_list_t *list, void *node_data);

#endif

