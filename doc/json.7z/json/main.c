
#include <stdio.h>
#include <conio.h>

#include "json.h"
#include "json_parser.h"

int main()
{
	int r;
	json_value_t *v;

	yyrestart(stdin);

	r = yyparse((void **)(&v));

	json_destroy_value(v);

	_getch();
}

#include "json_parser.c"
